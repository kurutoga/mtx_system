
#ifndef __SYS_RESOURCE_H
#define __SYS_RESOURCE_H
#include <features.h>
#include __SYSINC__(resource.h)
#endif
